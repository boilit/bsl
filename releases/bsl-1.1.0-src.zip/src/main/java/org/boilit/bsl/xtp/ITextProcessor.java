package org.boilit.bsl.xtp;

/**
 * @author Boilit
 * @see
 */
public interface ITextProcessor {

    public String process(String value);
}
