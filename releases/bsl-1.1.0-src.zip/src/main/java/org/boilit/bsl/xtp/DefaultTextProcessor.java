package org.boilit.bsl.xtp;

/**
 * @author Boilit
 * @see
 */
public final class DefaultTextProcessor implements ITextProcessor {
    @Override
    public final String process(final String value) {
        return value;
    }
}
