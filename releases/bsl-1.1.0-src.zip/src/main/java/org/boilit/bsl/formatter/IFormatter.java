package org.boilit.bsl.formatter;

/**
 * @author Boilit
 * @see
 */
public interface IFormatter {

    public String format(final Object object);

    public String getFormat();
}
