package org.boilit.bsl.core;

/**
 * @author Boilit
 * @see
 */
public interface IExecute {

    public Object execute(final ExecuteContext context) throws Exception;
}