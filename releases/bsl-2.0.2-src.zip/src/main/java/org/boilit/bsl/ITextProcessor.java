package org.boilit.bsl;

/**
 * @author Boilit
 * @see
 */
public interface ITextProcessor {

    public String process(String value);
}
