package org.boilit.bsl.core;

import org.boilit.bsl.Context;

/**
 * @author Boilit
 * @see
 */
public interface IExecute {

    public Object execute(final Context context) throws Exception;
}