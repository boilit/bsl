package test;

import org.boilit.bsl.Context;
import org.boilit.bsl.IEngine;
import org.boilit.bsl.IBreakPointer;
import org.boilit.bsl.ITemplate;

/**
 * @author Boilit
 * @see
 */
public class MyBpw implements IBreakPointer {
    @Override
    public void watch(IEngine engine, ITemplate template, Context context) {
    }
}
