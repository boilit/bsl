package org.boilit.bsl;

/**
 * @author Boilit
 * @see
 */
public interface IBreakPointer {
    public void watch(final IEngine engine, final ITemplate template, final Context context);
}
